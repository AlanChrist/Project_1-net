﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CheapLoansApp
{
    public partial class DisplayForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            totalLoans();

            DataView dv = new DataView();
            dv = (DataView) LoanDataSource0.Select(DataSourceSelectArguments.Empty);
            Label1.Text = dv.Table.Rows[0].Field<Decimal>(0).ToString();
        }

        protected void ButtonHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("MainForm.aspx");
            
        }
        public static double totalLoans()
        {            
            return 2.4;
        }
    }
}